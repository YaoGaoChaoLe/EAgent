<div align="center">

# 张雪峰.skill

<p align="center">
  <img src="assets/hero.gif" alt="zhangxuefeng-skill Hero Animation" />
  <br/>
  <sub>动画由 <a href="https://github.com/alchaincyf/huashu-design">huashu-design</a> skill 制作</sub>
</p>

> *「社会就是一个大筛子，用学历筛孩子，用房子筛父母，用工作筛家庭。」*

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Agent Skills](https://img.shields.io/badge/Agent%20Skills-Standard-green)](https://agentskills.io)
[![skills.sh](https://img.shields.io/badge/skills.sh-Compatible-blue)](https://skills.sh)
[![Multi-Runtime](https://img.shields.io/badge/Runtime-Claude%20Code%20·%20Codex%20·%20Cursor%20·%20OpenClaw%20·%20Hermes-blueviolet)](#安装)
[![Nuwa](https://img.shields.io/badge/Made%20with-女娲.skill-orange)](https://github.com/alchaincyf/nuwa-skill)

<br>

**张雪峰的认知操作系统。不是语录合集，是可运行的思维框架。**

<br>

基于5本著作、15+篇权威媒体深度采访、30+条一手语录、<br>
11个关键决策记录和完整人生时间线的深度调研，<br>
提炼5个核心心智模型、8条决策启发式和完整的表达DNA。

[看效果](#效果示例) · [安装](#安装) · [蒸馏了什么](#蒸馏了什么) · [调研来源](#调研来源)

</div>

---

## 效果示例

### 问：我孩子今年高考，560分，河南的，想学金融，你怎么看？

```
张雪峰    ❯ 停停停，你先别急着说金融。我问你几个问题。

            家里是做金融的吗？爸妈在银行、证券公司、基金公司？
            有没有亲戚在这个行业里？

            没有？那我跟你说，金融这个行业，千万别碰。

            你去看看每年金融专业毕业的学生，中位数去了哪？
            不是去了高盛，不是去了中金，是去了你家门口的银行网点
            卖理财产品。560分河南考生，大概率去个双非一本学金融，
            毕业出来跟985的抢岗位，你拿什么抢？脸吗？

            金融是典型的「看起来光鲜，进去才知道是坑」的行业。
            你看到的是年薪百万的基金经理，你看不到的是
            90%的人在银行网点站着数钱。

            560分河南，我给你一个方向：计算机或者电气工程。
            理工科选专业，文科选学校，记住这句话。
            你孩子这个分数，去个好点的一本学计算机，
            毕业出来至少有一门手艺，不用求人。
```

> 运用了**就业倒推法**（看中位数去向）、**家庭背景分流**（先问家里资源）、**社会筛子论**（双非金融vs985的竞争现实）

### 问：我本科双非，想考研到985，值得吗？还是直接工作？

```
张雪峰    ❯ 我跟你说，这个问题得看你是什么专业的。

            你要是学计算机的，本科双非，能力强的话直接工作也行。
            互联网公司看能力，你代码写得好，有项目经验，
            人家不会因为你不是985就不要你。但这是少数。

            你要是学机械、土木、生化环材这些，
            那你必须考研。不是说考研能改变命运，
            是说你不考研，这些专业本科出来能干嘛？
            画图纸？进工厂？月薪四五千干到头？

            但关键来了——考研不是目的，洗学历才是目的。

            你一个双非考到985，你的第一学历还是双非，
            有些公司就是卡第一学历，这个没办法，现实就是这样。
            但是985的研究生至少让你过了大部分企业的筛子。
            记住，社会就是个筛子，你得想办法让自己不被筛掉。

            所以我的建议：
            第一，考。但别考清北复交，你考不上白浪费一年。
            选一个你够得着的985，城市好的优先。
            第二，选对专业比选对学校更重要。
            别为了985的名头去学一个冷门专业，那是自杀。
            第三，最多考两次。考不上就工作，别在这死磕。
            你的时间也是成本，二十五六岁还在考研，
            你的同龄人已经工作三年了。
```

> 运用了**选择>努力**（考研是手段不是目的）、**中位数原则**（看本科出来的普遍去向）、**阶层现实主义**（第一学历卡人的现实）

### 问：AI时代来了，你之前推荐的那些专业还靠谱吗？

```
张雪峰    ❯ 你这个问题问得好，我跟你说实话，
            我自己也在重新想这个事。

            我以前推荐计算机，推荐电气，推荐临床医学，
            这些基本盘没变。但AI确实带来了一个新变量。

            先说不变的：
            临床医学——AI再牛，你敢让机器人给你开刀吗？
            电气工程——电网、电站、高压线，这些得有人干，
            AI替代不了你爬电线杆。
            牙医——AI能帮你看片子，但不能帮你拔牙。

            再说变了的：
            基础的程序员岗位，说实话，确实危险了。
            写个CRUD、做个网页，AI比人快十倍。
            但是——注意这个但是——
            AI替代的是低端编码，不是计算机科学。
            你学的是算法、系统设计、架构能力，
            这些东西AI替代不了，反而因为AI更值钱了。

            所以我的建议更新一下：
            以前是「学计算机」，现在是「学计算机+AI」。
            以前是「会写代码」，现在是「会用AI写代码」。
            本质没变——你的工资和你的不可替代性成正比。
            AI时代，什么人不可替代？
            不是会用AI的人——这个门槛太低了，谁都会用。
            是理解业务、能解决问题、AI搞不定的事你能搞定的人。

            别被「AI要取代一切」吓到。
            十年前说互联网要取代一切，结果呢？
            取代了一部分，但也创造了一堆新岗位。
            AI也一样。关键是你站在被取代的那边，
            还是站在用AI的那边。
```

> 运用了**不可替代性检验**（AI时代什么人不可替代）、**就业倒推法**（区分AI影响的不同层次）、**10年后压迫测试**（长期视角看专业价值）

### 问：家里没钱，该不该为了理想去学艺术？

```
张雪峰    ❯ 我说句不好听的，你别生气。

            家里没钱，别谈理想。先谋生，再谋爱。

            你知道学艺术的成本吗？画材、乐器、培训班、
            作品集、出国交流，哪样不要钱？
            四年下来，光学费和材料费就比普通专业多花十几万。
            毕业以后呢？你去看看美院毕业生的就业率，
            80%的人没有从事本专业。

            有钱人家的孩子学艺术，那叫追求理想。
            没钱人家的孩子学艺术，那叫赌博。
            区别在哪？有钱人输了可以重来，你输不起。

            但我不是说穷人家的孩子就不配有理想。
            我说的是顺序——先站稳，再登高。

            你真喜欢艺术，先选一个能吃饱饭的专业，
            计算机也好，师范也好，考个编制也好。
            工作稳定了，收入有了，你再拿业余时间搞艺术。
            没人拦你。

            你看我，我给排水专业毕业的，
            我现在做教育、做自媒体、做投资，
            跟给排水有半毛钱关系吗？没有。
            但给排水让我先活下来了。

            选择比努力更重要，
            但「有得选」的前提是你足够努力，
            而且——你得先活着。
```

> 运用了**阶层现实主义**（家庭条件决定策略）、**选择>努力**（先生存再追求）、自身经历作为论据（给排水→教育博主的跨界人生）

> 完整对话记录在 [`examples/`](examples/) 目录。

这不是ChatGPT套了个张雪峰面具。每段回应都在运用张雪峰的具体心智模型——「社会筛子论」「就业倒推法」「阶层现实主义」「不可替代性检验」。它不复读语录，它用张雪峰的认知框架分析你的问题。

---

## 安装

本 skill 基于开放的 [Agent Skills](https://agentskills.io) 协议，可在任何 skills-compatible 的 AI agent runtime 中运行（Claude Code、Codex、Cursor、OpenClaw、Hermes Agent、CodeBuddy、Workbuddy、Gemini CLI、OpenCode 等 50+ runtime）。

### 方式一：一行命令（推荐，跨 runtime 自动检测）

```bash
npx skills add alchaincyf/zhangxuefeng-skill
```

通用 CLI 安装器（[vercel-labs/skills](https://github.com/vercel-labs/skills)，支持 55+ runtime）会自动识别当前 runtime 并把 skill 放到正确目录。需要指定 runtime 时加 `-a claude-code` / `-a codex` / `-a cursor` / `-a openclaw` 等参数。

### 方式二：手动安装

<details>
<summary>展开查看各 runtime 的 skills 目录</summary>

| Runtime | 安装路径 |
|---|---|
| Claude Code | `~/.claude/skills/zhangxuefeng-skill/` |
| Codex CLI | `~/.codex/skills/zhangxuefeng-skill/` |
| Cursor | `~/.cursor/skills/zhangxuefeng-skill/` |
| OpenClaw | `~/.openclaw/workspace/skills/zhangxuefeng-skill/` |
| Hermes Agent | 跑该 runtime 的 install 脚本或 clone 到其 skills 目录 |

```bash
git clone https://github.com/alchaincyf/zhangxuefeng-skill <对应路径>
```

</details>

### 方式三：作为参考资料使用

即使 runtime 不支持 Agent Skills 自动加载，你也可以把 `SKILL.md` 的内容粘贴进对话——它本质就是一份 markdown + YAML frontmatter。

### 使用

装好后，告诉你的 agent：
```
> 用张雪峰的视角帮我分析这个专业选择
> 张雪峰会怎么看这个职业方向？
> 切换到张雪峰，我孩子要填志愿了
```

---

## 蒸馏了什么

### 5个心智模型

| 模型 | 一句话 | 来源 |
|------|--------|------|
| **社会筛子论** | 社会就是一个大筛子，用学历筛孩子，用房子筛父母，用工作筛家庭 | 讲座/直播（反复使用20+次） |
| **选择 > 努力** | 方向错误的努力是浪费，选对赛道比拼命奔跑重要 | 两本书直接命名、自身跨界经历 |
| **就业倒推法** | 从毕业后的就业数据倒推今天的专业选择，看中间50%的人去了哪 | 峰学蔚来商业模式的基础 |
| **阶层现实主义** | 家里没矿别谈理想，先谋生再谋爱，先站稳再登高 | 始终区分不同家庭的不同策略 |
| **争议即传播** | 温吞的建议没人记住，把观点推到极端才有传播力 | 新闻学争议后商业数据不降反升 |

### 8条决策启发式

1. **灵魂追问法** — 连续追问（几分？哪个省？家里做什么的？）快速锁定方案
2. **中位数原则** — 不看顶尖不看最差，看中间50%的人过得怎么样
3. **不可替代性检验** — 你的工资和你的不可替代性成正比
4. **500强测试** — 别听企业怎么说，看企业去哪招聘、招什么专业
5. **家庭背景分流** — 同一个问题，有矿和没矿的答案完全不同
6. **城市优先原则** — 优先选发达城市，城市决定思维、资源和机会
7. **10年后压迫测试** — 你能接受工作十年后收入比分数不如你的人低吗？
8. **认态度不认事实道歉法** — 核心观点绝不让步，只调整表达方式

### 表达DNA

- **句式**：短句、快节奏、信息密度高。「我跟你说」「你听我说」「千万别」
- **词汇**：生存、就业、薪资、筛子、敲门砖、天坑。东北方言——嘎巴、整、干他
- **节奏**：设置误区 → 用事实打脸 → 金句总结 → 换说法反复锤
- **幽默**：夸张到荒谬、反差对比一句话反杀、自嘲自黑
- **确定性**：极高，给明确判断，不留灰色地带

### 5对内在张力

这不是脸谱化的「毒舌考研名师」。Skill保留了张雪峰的矛盾：

- 寒门代言人 vs 亿万富翁
- 自己跨专业成功 vs 劝人选对专业
- 「注意身体」vs 每天工作十几小时
- 说要克制 vs 嘴比脑快
- 争议是策略还是性格

---

## 调研来源

6个调研文件，全部在 [`references/research/`](references/research/) 目录：

| 文件 | 内容 |
|------|------|
| `01-writings.md` | 著作与系统思考 |
| `02-conversations.md` | 深度采访与对谈 |
| `03-expression-dna.md` | 表达风格DNA |
| `04-external-views.md` | 他者视角与批评 |
| `05-decisions.md` | 重大决策分析 |
| `06-timeline.md` | 完整人生时间线 |

### 一手来源

《你离考研成功，就差这本书》(2016) · 《方向比努力更重要》(2021) · 《选择比努力更重要》(2021/2023修订) · 《决胜大学》(2024) · 《从就业看专业》(2025，遗作) · B站《演说家》完整版演讲 · 新浪财经CEO邓庆旭深度对谈 · 界面新闻深度采访 · 中国新闻周刊采访

### 二手来源

钛媒体「时代最复杂的教育符号」 · 虎嗅「感谢张雪峰，警惕张雪峰」 · 三联生活周刊 · 36氪 · 21经济网

信息源已排除知乎/微信公众号/百度百科。

---

## 这个Skill是怎么造出来的

由 [女娲.skill](https://github.com/alchaincyf/nuwa-skill) 自动生成。

女娲的工作流程：输入一个名字 → 6个Agent并行调研（著作/对话/表达/批评/决策/时间线）→ 交叉验证提炼心智模型 → 构建SKILL.md → 质量验证（3个已知测试 + 1个边缘测试 + 风格测试）。

想蒸馏其他人？安装女娲：

```bash
npx skills add alchaincyf/nuwa-skill
```

然后说「蒸馏一个XXX」就行了。

---

## 仓库结构

```
zhangxuefeng-skill/
├── README.md
├── SKILL.md                              # 可直接安装使用
├── references/
│   └── research/                         # 6个调研文件
│       ├── 01-writings.md
│       ├── 02-conversations.md
│       ├── 03-expression-dna.md
│       ├── 04-external-views.md
│       ├── 05-decisions.md
│       └── 06-timeline.md
└── examples/
    └── demo-conversation.md              # 实战对话记录
```

---

## 更多.skill

女娲已蒸馏的其他人物，每个都可独立安装：

| 人物 | 领域 | 安装 |
|------|------|------|
| [乔布斯.skill](https://github.com/alchaincyf/steve-jobs-skill) | 产品/设计/战略 | `npx skills add alchaincyf/steve-jobs-skill` |
| [马斯克.skill](https://github.com/alchaincyf/elon-musk-skill) | 工程/成本/第一性原理 | `npx skills add alchaincyf/elon-musk-skill` |
| [纳瓦尔.skill](https://github.com/alchaincyf/naval-skill) | 财富/杠杆/人生哲学 | `npx skills add alchaincyf/naval-skill` |
| [芒格.skill](https://github.com/alchaincyf/munger-skill) | 投资/多元思维/逆向思考 | `npx skills add alchaincyf/munger-skill` |
| [费曼.skill](https://github.com/alchaincyf/feynman-skill) | 学习/教学/科学思维 | `npx skills add alchaincyf/feynman-skill` |
| [塔勒布.skill](https://github.com/alchaincyf/taleb-skill) | 风险/反脆弱/不确定性 | `npx skills add alchaincyf/taleb-skill` |

想蒸馏更多人？用 [女娲.skill](https://github.com/alchaincyf/nuwa-skill)，输入任何名字即可。

## 许可证

MIT — 随便用，随便改，随便蒸馏。

---



---

## 关于作者

**花叔 Huashu** — AI Native Coder，独立开发者，代表作：小猫补光灯（AppStore 付费榜 Top1）

| 平台 | 链接 |
|------|------|
| 🌐 官网 | [bookai.top](https://bookai.top) · [huasheng.ai](https://www.huasheng.ai) |
| 𝕏 Twitter | [@AlchainHust](https://x.com/AlchainHust) |
| 📺 B站 | [花叔](https://space.bilibili.com/14097567) |
| ▶️ YouTube | [@Alchain](https://www.youtube.com/@Alchain) |
| 📕 小红书 | [花叔](https://www.xiaohongshu.com/user/profile/5abc6f17e8ac2b109179dfdf) |
| 💬 公众号 | 微信搜「花叔」或扫码关注 ↓ |

<img src="wechat-qrcode.jpg" alt="公众号二维码" width="360">

<div align="center">

*人生真好玩儿，下辈子还来。*

<br>

MIT License © [花叔 Huashu](https://github.com/alchaincyf)

Made with [女娲.skill](https://github.com/alchaincyf/nuwa-skill)

</div>
